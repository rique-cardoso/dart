# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\tools\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\tools\\flutter"
  "PROJECT_DIR=C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab"
  "FLUTTER_ROOT=C:\\tools\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab"
  "FLUTTER_TARGET=C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZmYzN2JlZjYwMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZTRiOGRjYTNmMQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\henri\\Documents\\estudos-tech\\dart\\estudando-dart\\aula04\\patterns_codelab\\.dart_tool\\package_config.json"
)
